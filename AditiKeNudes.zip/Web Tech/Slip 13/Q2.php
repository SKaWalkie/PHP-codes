<!DOCTYPE html>
<html>
<body>

<?php
session_start();

// Set correct credentials
$valid_user = "admin";
$valid_pass = "1234";

// Initialize attempt count
if (!isset($_SESSION['attempts'])) {
    $_SESSION['attempts'] = 0;
}

// Check if already logged in
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] == true) {
    echo "<h3>Welcome, $valid_user!</h3>";
    echo "<form method='post'><input type='submit' name='logout' value='Logout'></form>";

    if (isset($_POST['logout'])) {
        session_destroy();
        header("Refresh:0");
    }
    exit;
}

// Stop if 3 failed attempts
if ($_SESSION['attempts'] >= 3) {
    echo "<p><b>Access Denied.</b> You have exceeded 3 login attempts.</p>";
    session_destroy();
    exit;
}

// Handle login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $u = $_POST['uname'];
    $p = $_POST['pass'];

    if ($u == $valid_user && $p == $valid_pass) {
        $_SESSION['logged_in'] = true;
        echo "<h3>Welcome, $valid_user!</h3>";
        exit;
    } else {
        $_SESSION['attempts']++;
        echo "Invalid Username or Password. Attempts: " . $_SESSION['attempts'] . "<br><br>";
    }
}
?>

<form method="post" action="">
    Username: <input type="text" name="uname"><br><br>
    Password: <input type="password" name="pass"><br><br>
    <input type="submit" value="Login">
</form>

</body>
</html>
