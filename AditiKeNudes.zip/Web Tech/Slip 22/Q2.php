<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
  Hospital Name:
  <input type="text" name="hname" value="<?php if(isset($_POST['hname'])) echo $_POST['hname']; ?>">
  <input type="submit" value="Show Count">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $hname = trim($_POST['hname']);
    if ($hname === "") { echo "Please enter hospital name."; exit; }

    $conn = pg_connect("host=localhost dbname=yourdb user=youruser password=yourpass");
    if (!$conn) { die("DB connection failed."); }

    $sql = "
      SELECT h.hname, COUNT(d.doc_no) AS doc_count
      FROM Hospital h
      LEFT JOIN Doctor d ON d.hosp_no = h.hosp_no
      WHERE h.hname = $1
      GROUP BY h.hname";
    $res = pg_query_params($conn, $sql, [$hname]);

    echo "<table border='1'>
            <tr><th>Hospital</th><th>Number of Doctors</th></tr>";

    if (pg_num_rows($res) == 0) {
        echo "<tr><td colspan='2'>Hospital not found: $hname</td></tr>";
    } else {
        $row = pg_fetch_assoc($res);
        echo "<tr><td>{$row['hname']}</td><td>{$row['doc_count']}</td></tr>";
    }
    echo "</table>";

    pg_close($conn);
}
?>
</body>
</html>
