<!DOCTYPE html>
<html>
<body>

<form method="post" enctype="multipart/form-data" action="">
    Select File: <input type="file" name="file"><br><br>
    <input type="submit" value="Upload">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $name = $_FILES['file']['name'];
        $tmp  = $_FILES['file']['tmp_name'];

        // Create folder if not exists
        if (!is_dir("uploads")) mkdir("uploads");
        
        $dest = "uploads/" . $name;
        move_uploaded_file($tmp, $dest);

        $size = filesize($dest);
        $mtime = date("d-m-Y H:i:s", filemtime($dest));

        echo "<h3>File Uploaded Successfully!</h3>";
        echo "File Name: $name<br>";
        echo "File Size: $size bytes<br>";
        echo "Last Modified: $mtime";
    } else {
        echo "Please select a valid file to upload.";
    }
}
?>

</body>
</html>
