<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
  Enter Route No: 
  <input type="text" name="rno" value="<?php if(isset($_POST['rno'])) echo $_POST['rno']; ?>">
  <input type="submit" value="Get Details">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rno = trim($_POST['rno']);
    if ($rno === "" || !is_numeric($rno)) { echo "Enter a valid route number."; exit; }

    $conn = pg_connect("host=localhost dbname=yourdb user=youruser password=yourpass");
    if (!$conn) { die("DB connection failed."); }

    $sql = "SELECT route_no, source, destination, no_of_stations
            FROM Route WHERE route_no = $1";
    $res = pg_query_params($conn, $sql, [ $rno ]);

    if (pg_num_rows($res) == 0) {
        echo "No route found for route_no: $rno";
    } else {
        echo "<table border='1'>
                <tr><th>Route No</th><th>Source</th><th>Destination</th><th>No. of Stations</th></tr>";
        while ($row = pg_fetch_assoc($res)) {
            echo "<tr>
                    <td>{$row['route_no']}</td>
                    <td>{$row['source']}</td>
                    <td>{$row['destination']}</td>
                    <td>{$row['no_of_stations']}</td>
                  </tr>";
        }
        echo "</table>";
    }
    pg_close($conn);
}
?>
</body>
</html>
