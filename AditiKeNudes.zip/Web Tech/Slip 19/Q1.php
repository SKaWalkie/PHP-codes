<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter Filename: <input type="text" name="fname">
    <input type="submit" value="Read File">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST['fname'];

    if (file_exists($fname)) {
        $fp = fopen($fname, "r");
        $size = filesize($fname);
        if ($size > 0) {
            $data = fread($fp, $size);
            echo "<h3>File Contents:</h3><pre>$data</pre>";
        } else {
            echo "File is empty.";
        }
        fclose($fp);
    } else {
        echo "File '$fname' does not exist.";
    }
}
?>

</body>
</html>
