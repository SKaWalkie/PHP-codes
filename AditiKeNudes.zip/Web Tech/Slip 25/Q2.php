<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter First File Name: <input type="text" name="file1"><br><br>
    Enter Second File Name: <input type="text" name="file2"><br><br>
    <input type="submit" value="Copy Content">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $f1 = $_POST['file1'];
    $f2 = $_POST['file2'];

    if (file_exists($f1)) {
        $src = fopen($f1, "r") or die("Unable to open source file!");
        $dest = fopen($f2, "w") or die("Unable to open destination file!");

        while (!feof($src)) {
            $line = fgets($src);
            fwrite($dest, $line);
        }

        fclose($src);
        fclose($dest);

        echo "Contents of '$f1' copied successfully into '$f2'.";
    } else {
        echo "Source file '$f1' does not exist.";
    }
}
?>

</body>
</html>
