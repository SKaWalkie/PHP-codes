<!DOCTYPE html>
<html>
<body>

<?php
// Create JSON object
$jsonData = '{
    "route_no": 101,
    "source": "Pune",
    "destination": "Mumbai",
    "no_of_stations": 8
}';

// Decode JSON to PHP associative array
$route = json_decode($jsonData, true);

// Display route details
echo "<h3>Route Details</h3>";
echo "Route No: " . $route['route_no'] . "<br>";
echo "Source: " . $route['source'] . "<br>";
echo "Destination: " . $route['destination'] . "<br>";
echo "Number of Stations: " . $route['no_of_stations'];
?>

</body>
</html>
