<?php
// Build XML
$doc = new DOMDocument('1.0', 'UTF-8');
$doc->formatOutput = true;

// Link CSS
$pi = $doc->createProcessingInstruction('xml-stylesheet','type="text/css" href="item.css"');
$doc->appendChild($pi);

$root = $doc->createElement('Items');
$doc->appendChild($root);

$items = [
    ['Laptop',     '55000', '2'],
    ['Mouse',      '599',   '10'],
    ['Keyboard',   '899',   '6'],
    ['Monitor',    '7999',  '3'],
    ['PenDrive',   '499',   '15']
];

foreach ($items as $it) {
    $item = $doc->createElement('Item');
    $item->appendChild($doc->createElement('ItemName',  $it[0]));
    $item->appendChild($doc->createElement('ItemPrice', $it[1]));
    $item->appendChild($doc->createElement('Quantity',  $it[2]));
    $root->appendChild($item);
}

$doc->save('Item.xml');

// Write CSS
$css = <<<CSS
ItemName {
  color: red;
  font-family: "Copperplate Gothic Light", serif;
  font-size: 16pt;
  font-weight: bold;
}
ItemPrice, Quantity {
  color: yellow;
  font-family: Arial, sans-serif;
  font-size: 12pt;
  font-weight: bold;
}
CSS;

file_put_contents('item.css', $css);

echo "Item.xml and item.css created. Open Item.xml in a browser.";
