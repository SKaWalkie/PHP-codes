<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
  Enter Source: 
  <input type="text" name="src" value="<?php if(isset($_POST['src'])) echo $_POST['src']; ?>">
  <input type="submit" value="Get Routes">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $src = trim($_POST['src']);
    if ($src === "") { echo "Please enter a source."; exit; }

    $conn = pg_connect("host=localhost dbname=yourdb user=youruser password=yourpass");
    if (!$conn) { die("DB connection failed."); }

    // Use ILIKE for case-insensitive match; parameterized for safety
    $sql = "SELECT route_no, source, destination, no_of_stations
            FROM Route
            WHERE source ILIKE $1
            ORDER BY route_no";
    $res = pg_query_params($conn, $sql, [ $src ]);

    if (pg_num_rows($res) == 0) {
        echo "No routes found for source: $src";
    } else {
        echo "<table border='1'>
                <tr><th>Route No</th><th>Source</th><th>Destination</th><th>No. of Stations</th></tr>";
        while ($row = pg_fetch_assoc($res)) {
            echo "<tr>
                    <td>{$row['route_no']}</td>
                    <td>{$row['source']}</td>
                    <td>{$row['destination']}</td>
                    <td>{$row['no_of_stations']}</td>
                  </tr>";
        }
        echo "</table>";
    }
    pg_close($conn);
}
?>
</body>
</html>
