<!DOCTYPE html>
<html>
<body>

<?php
$xml = new DOMDocument("1.0", "UTF-8");
$xml->formatOutput = true;

$root = $xml->createElement("NovelInfo");
$xml->appendChild($root);

$novels = [
    ["1", "Jane Eyre", "Charlotte Bronte", "250", "2006"],
    ["2", "Frankenstein", "Mary Shelley", "500", "1971"]
];

foreach ($novels as $n) {
    $novel = $xml->createElement("novel");

    $novel->appendChild($xml->createElement("novelno", $n[0]));
    $novel->appendChild($xml->createElement("novelname", $n[1]));
    $novel->appendChild($xml->createElement("authorname", $n[2]));
    $novel->appendChild($xml->createElement("price", $n[3]));
    $novel->appendChild($xml->createElement("year", $n[4]));

    $root->appendChild($novel);
}

$xml->save("NovelInfo.xml");
echo "NovelInfo.xml created successfully.";
?>

</body>
</html>
