<!DOCTYPE html>
<html>
<body>

<?php
$fp = fopen("student.dat", "r");

echo "<table border='1'>";
echo "<tr>
        <th>Roll No</th>
        <th>Name</th>
        <th>OS</th>
        <th>WT</th>
        <th>DS</th>
        <th>Python</th>
        <th>Percentage</th>
      </tr>";

while (!feof($fp)) {
    $line = trim(fgets($fp));
    if ($line == "") continue;

    list($rno, $name, $os, $wt, $ds, $py) = explode(" ", $line);
    $per = ($os + $wt + $ds + $py) / 4;

    echo "<tr>
            <td>$rno</td>
            <td>$name</td>
            <td>$os</td>
            <td>$wt</td>
            <td>$ds</td>
            <td>$py</td>
            <td>$per</td>
          </tr>";
}

echo "</table>";
fclose($fp);
?>

</body>
</html>
