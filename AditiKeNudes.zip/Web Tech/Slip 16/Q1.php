<?php
// Create XML
$doc = new DOMDocument('1.0', 'UTF-8');
$doc->formatOutput = true;

// Link CSS (xml-stylesheet PI)
$pi = $doc->createProcessingInstruction('xml-stylesheet', 'type="text/css" href="product.css"');
$doc->appendChild($pi);

// Root
$root = $doc->createElement('Products');
$doc->appendChild($root);

// Data: 5 products
$products = [
    ['Laptop', '55000', '2'],
    ['Mouse', '599', '10'],
    ['Keyboard', '899', '6'],
    ['Monitor', '7999', '3'],
    ['Pendrive', '499', '15']
];

foreach ($products as $p) {
    $prod = $doc->createElement('Product');
    $prod->appendChild($doc->createElement('ProductName',  $p[0]));
    $prod->appendChild($doc->createElement('ProductPrice', $p[1]));
    $prod->appendChild($doc->createElement('Quantity',     $p[2]));
    $root->appendChild($prod);
}

// Save XML
$doc->save('Item.xml');

// Write CSS
$css = <<<CSS
ProductName {
  color: red;
  font-family: "Copperplate Gothic Light", serif;
  font-size: 16pt;
  font-weight: bold;
}
CSS;

file_put_contents('product.css', $css);

echo "Created Item.xml and product.css. Open Item.xml in a browser.";
