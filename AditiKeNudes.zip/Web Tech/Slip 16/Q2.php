<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
  Department Name: 
  <input type="text" name="dname" value="<?php if(isset($_POST['dname'])) echo $_POST['dname']; ?>">
  <input type="submit" value="Show Count">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"]=="POST") {
    $dname = trim($_POST['dname']);
    if ($dname === "") { echo "Please enter department name."; exit; }

    $conn = pg_connect("host=localhost dbname=yourdb user=youruser password=yourpass");
    if (!$conn) { die("DB connection failed."); }

    $sql = "
      SELECT COUNT(*) AS cnt
      FROM Emp e
      JOIN Dept d ON e.dno = d.dno
      WHERE d.dname = $1";                 // use ILIKE $1 for case-insensitive
    $res = pg_query_params($conn, $sql, [$dname]);
    $row = pg_fetch_assoc($res);

    echo "<h3>Employees in '$dname': " . $row['cnt'] . "</h3>";

    pg_close($conn);
}
?>
</body>
</html>
