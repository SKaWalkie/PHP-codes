<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter Filename: <input type="text" name="fname">
    <input type="submit" value="Show Access Time">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST['fname'];

    if (file_exists($fname)) {
        $time = date("d-m-Y H:i:s", fileatime($fname));
        echo "Last access time of '$fname' is: $time";
    } else {
        echo "File '$fname' does not exist.";
    }
}
?>

</body>
</html>
