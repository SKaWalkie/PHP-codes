<!DOCTYPE html>
<html>
<body>

<?php
$conn = pg_connect("host=localhost dbname=yourdb user=youruser password=yourpass");
if (!$conn) { die("DB connection failed."); }

$sql = "SELECT mname FROM Movie
        WHERE rating = (SELECT MAX(rating) FROM Movie)";
$res = pg_query($conn, $sql);

echo "<h3>Highest Rating Movie(s):</h3>";
while ($row = pg_fetch_assoc($res)) {
    echo $row['mname'] . "<br>";
}

pg_close($conn);
?>
</body>
</html>
