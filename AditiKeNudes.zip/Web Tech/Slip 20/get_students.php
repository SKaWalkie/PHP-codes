<?php
header('Content-Type: application/json');

$students = [
  ["rollno"=>101, "name"=>"Asha",  "age"=>20],
  ["rollno"=>102, "name"=>"Rohan", "age"=>21],
  ["rollno"=>103, "name"=>"Meera", "age"=>19]
];

echo json_encode($students);
