<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter a Number: 
    <input type="text" name="num" value="<?php if(isset($_POST['num'])) echo $_POST['num']; ?>">
    <input type="submit" value="Check">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $n = $_POST['num'];

    if ($n == "" || !is_numeric($n) || $n <= 0) {
        echo "<p>Please enter a valid positive number.</p>";
    } else {
        $sum = 0;
        for ($i = 1; $i <= $n/2; $i++) {
            if ($n % $i == 0) {
                $sum += $i;
            }
        }
        if ($sum == $n)
            echo "<h3>$n is a Perfect Number.</h3>";
        else
            echo "<h3>$n is not a Perfect Number.</h3>";
    }
}
?>

</body>
</html>
