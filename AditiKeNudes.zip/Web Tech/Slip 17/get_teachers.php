<?php
$conn = pg_connect("host=localhost dbname=yourdb user=youruser password=yourpass");
if (!$conn) { http_response_code(500); exit("DB connection failed."); }

$res = pg_query($conn, 'SELECT Tno, "Name", "Subject", "Research area" FROM Teacher ORDER BY Tno');

echo "<table border='1'>
        <tr><th>Tno</th><th>Name</th><th>Subject</th><th>Research area</th></tr>";
while ($row = pg_fetch_assoc($res)) {
    echo "<tr>
            <td>{$row['tno']}</td>
            <td>{$row['Name']}</td>
            <td>{$row['Subject']}</td>
            <td>{$row['Research area']}</td>
          </tr>";
}
echo "</table>";

pg_close($conn);
