<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
  Hospital Name: <input type="text" name="hname" value="<?php if(isset($_POST['hname'])) echo $_POST['hname']; ?>">
  <input type="submit" value="Get Doctors">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $hname = trim($_POST['hname']);
    if ($hname === "") { echo "Please enter hospital name."; exit; }

    $conn = pg_connect("host=localhost dbname=yourdb user=youruser password=yourpass");
    if (!$conn) { die("DB connection failed."); }

    $sql = "
      SELECT d.doc_no, d.dname, d.address, d.city, d.area
      FROM Doctor d
      JOIN Hospital h ON d.hosp_no = h.hosp_no
      WHERE h.hname = $1
      ORDER BY d.doc_no";
    $res = pg_query_params($conn, $sql, [$hname]);

    if (pg_num_rows($res) == 0) {
        echo "No doctors found for hospital: $hname";
    } else {
        echo "<h3>Doctors visiting $hname</h3>";
        echo "<table border='1'>
                <tr><th>Doc No</th><th>Name</th><th>Address</th><th>City</th><th>Area</th></tr>";
        while ($row = pg_fetch_assoc($res)) {
            echo "<tr>
                    <td>{$row['doc_no']}</td>
                    <td>{$row['dname']}</td>
                    <td>{$row['address']}</td>
                    <td>{$row['city']}</td>
                    <td>{$row['area']}</td>
                  </tr>";
        }
        echo "</table>";
    }
    pg_close($conn);
}
?>
</body>
</html>
