<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter a Number: 
    <input type="text" name="num" value="<?php if(isset($_POST['num'])) echo $_POST['num']; ?>">
    <input type="submit" value="Show Factors">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $n = $_POST['num'];
    if ($n == "" || !is_numeric($n) || $n <= 0) {
        echo "<p>Please enter a valid positive number.</p>";
    } else {
        echo "<h3>Factors of $n are:</h3>";
        for ($i = 1; $i <= $n; $i++) {
            if ($n % $i == 0) {
                echo $i . " ";
            }
        }
    }
}
?>

</body>
</html>
