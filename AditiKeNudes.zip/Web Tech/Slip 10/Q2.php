<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter a String: 
    <input type="text" name="str" value="<?php if(isset($_POST['str'])) echo $_POST['str']; ?>">
    <input type="submit" value="Reverse Words">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $str = trim($_POST['str']);
    if ($str != "") {
        $words = explode(" ", $str);
        echo "<h3>Reversed Words:</h3>";
        foreach ($words as $w) {
            echo strrev($w) . " ";
        }
    } else {
        echo "<p>Please enter a string.</p>";
    }
}
?>

</body>
</html>
