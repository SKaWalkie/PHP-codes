<!DOCTYPE html>
<html>
<body>

<?php
$xml = new DOMDocument("1.0", "UTF-8");
$xml->formatOutput = true;

$root = $xml->createElement("BookInfo");
$xml->appendChild($root);

$books = [
    ["1", "JAVA", "Balguru Swami", "250", "2006"],
    ["2", "C", "Deni Ritchie", "500", "1971"]
];

foreach ($books as $b) {
    $book = $xml->createElement("book");
    $book->appendChild($xml->createElement("bookno", $b[0]));
    $book->appendChild($xml->createElement("bookname", $b[1]));
    $book->appendChild($xml->createElement("authorname", $b[2]));
    $book->appendChild($xml->createElement("price", $b[3]));
    $book->appendChild($xml->createElement("year", $b[4]));
    $root->appendChild($book);
}

$xml->save("BookInfo.xml");
echo "BookInfo.xml created successfully.";
?>

</body>
</html>
