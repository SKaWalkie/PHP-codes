<!DOCTYPE html>
<html>
<body>

<form method="post" action="getuser.php">
    <input type="submit" name="get" value="Get User">
</form>

<?php
session_start();
if (isset($_POST['get'])) {
    if (isset($_SESSION['user']))
        echo "Username from session: " . $_SESSION['user'];
    else
        echo "No username stored in session.";
}
?>

</body>
</html>
