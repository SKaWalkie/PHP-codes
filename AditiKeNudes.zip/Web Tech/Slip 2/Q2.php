<!DOCTYPE html>
<html>
<body>

<?php
$conn = pg_connect("host=localhost dbname=yourdbname user=youruser password=yourpassword");

if (!$conn) {
    die("Connection failed");
}

$result = pg_query($conn, "SELECT * FROM Item");

echo "<table border='1'>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Price</th>
            <th>Rating</th>
        </tr>";

while ($row = pg_fetch_assoc($result)) {
    echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['name']}</td>
            <td>{$row['price']}</td>
            <td>{$row['rating']}</td>
          </tr>";
}

echo "</table>";

pg_close($conn);
?>

</body>
</html>
