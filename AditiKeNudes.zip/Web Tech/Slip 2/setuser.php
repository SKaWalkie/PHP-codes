<!DOCTYPE html>
<html>
<body>

<form method="post" action="setuser.php">
    Enter Username: <input type="text" name="uname">
    <input type="submit" value="Submit">
</form>

<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $_SESSION['user'] = $_POST['uname'];
    echo "Username stored in session.";
}
?>

</body>
</html>
