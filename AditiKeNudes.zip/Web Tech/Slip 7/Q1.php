<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter Filename: <input type="text" name="fname">
    <input type="submit" value="Check">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST['fname'];
    if (file_exists($fname)) {
        echo "File '$fname' exists.";
    } else {
        echo "File '$fname' does not exist.";
    }
}
?>

</body>
</html>
