<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Username: <input type="text" name="uname" value="<?php if(isset($_POST['uname'])) echo $_POST['uname']; ?>"><br><br>
    Age: <input type="text" name="age" value="<?php if(isset($_POST['age'])) echo $_POST['age']; ?>"><br><br>
    Email ID: <input type="text" name="email" value="<?php if(isset($_POST['email'])) echo $_POST['email']; ?>"><br><br>
    <input type="submit" value="Submit">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uname = $_POST['uname'];
    $age = $_POST['age'];
    $email = $_POST['email'];

    if ($uname != "" && $age != "" && $email != "") {
        echo "<h3>User Details:</h3>";
        echo "Username: $uname<br>";
        echo "Age: $age<br>";
        echo "Email ID: $email<br>";
    } else {
        echo "<p>Please fill all fields.</p>";
    }
}
?>

</body>
</html>
