<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
  Enter Salary: <input type="text" name="sal" value="<?php if(isset($_POST['sal'])) echo $_POST['sal']; ?>">
  <input type="submit" value="Show">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"]=="POST") {
    $s = trim($_POST['sal']);
    if ($s === "" || !is_numeric($s)) { echo "Enter a valid number."; exit; }

    $conn = pg_connect("host=localhost dbname=yourdb user=youruser password=yourpass");
    if (!$conn) { die("DB connection failed."); }

    $res = pg_query_params($conn, "SELECT Eid, Ename, Salary FROM Emp WHERE Salary > $1 ORDER BY Salary DESC", [ $s ]);

    echo "<table border='1'>
            <tr><th>Eid</th><th>Ename</th><th>Salary</th></tr>";
    while ($row = pg_fetch_assoc($res)) {
        echo "<tr>
                <td>{$row['eid']}</td>
                <td>{$row['ename']}</td>
                <td>{$row['salary']}</td>
              </tr>";
    }
    echo "</table>";

    pg_close($conn);
}
?>

</body>
</html>
