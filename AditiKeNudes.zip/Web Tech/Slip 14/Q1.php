<!DOCTYPE html>
<html>
<body>

<form method="post" enctype="multipart/form-data" action="">
    Select File: <input type="file" name="file"><br><br>
    <input type="submit" value="Upload">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $name = $_FILES['file']['name'];
        $size = $_FILES['file']['size'];
        $type = $_FILES['file']['type'];
        $tmp  = $_FILES['file']['tmp_name'];

        move_uploaded_file($tmp, "uploads/" . $name);

        echo "<h3>File Uploaded Successfully!</h3>";
        echo "File Name: $name <br>";
        echo "File Type: $type <br>";
        echo "File Size: $size bytes";
    } else {
        echo "Please select a valid file to upload.";
    }
}
?>

</body>
</html>
