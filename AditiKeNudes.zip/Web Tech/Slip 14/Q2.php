<!DOCTYPE html>
<html>
<body>

<?php
if (isset($_COOKIE['last_visit'])) {
    $last_visit = $_COOKIE['last_visit'];
    echo "Your last visit was on: " . $last_visit;
} else {
    echo "Welcome, You have visited for first time.";
}

$visit_time = date("d-m-Y H:i:s");
setcookie("last_visit", $visit_time, time() + 3600); // valid for 1 hour
?>

</body>
</html>
