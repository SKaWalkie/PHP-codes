<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
  Enter Owner Name: <input type="text" name="oname" value="<?php if(isset($_POST['oname'])) echo $_POST['oname']; ?>">
  <input type="submit" value="Show Properties">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"]=="POST") {
    $owner = trim($_POST['oname']);
    if ($owner === "") { echo "Please enter owner name."; exit; }

    $conn = pg_connect("host=localhost dbname=yourdb user=youruser password=yourpass");
    if (!$conn) { die("DB connection failed."); }

    $sql = "SELECT pno, description, area FROM Property WHERE oname = $1 ORDER BY pno";
    $res = pg_query_params($conn, $sql, [$owner]);

    if (pg_num_rows($res) == 0) {
        echo "No properties found for owner: $owner";
    } else {
        echo "<h3>Properties of $owner</h3>";
        echo "<table border='1'>
                <tr><th>Pno</th><th>Description</th><th>Area</th></tr>";
        while ($row = pg_fetch_assoc($res)) {
            echo "<tr>
                    <td>{$row['pno']}</td>
                    <td>{$row['description']}</td>
                    <td>{$row['area']}</td>
                  </tr>";
        }
        echo "</table>";
    }

    pg_close($conn);
}
?>
</body>
</html>
