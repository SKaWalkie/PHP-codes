<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter a Number: 
    <input type="text" name="num" value="<?php if(isset($_POST['num'])) echo $_POST['num']; ?>">
    <input type="submit" value="Find Factorial">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $n = $_POST['num'];
    if ($n == "" || !is_numeric($n) || $n < 0) {
        echo "<p>Please enter a valid positive number.</p>";
    } else {
        $fact = 1;
        for ($i = 1; $i <= $n; $i++) {
            $fact *= $i;
        }
        echo "<h3>Factorial of $n is: $fact</h3>";
    }
}
?>

</body>
</html>
