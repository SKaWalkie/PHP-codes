<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter Filename: <input type="text" name="fname" value="<?php if(isset($_POST['fname'])) echo $_POST['fname']; ?>"><br><br>
    <input type="radio" name="choice" value="type"> Display Type of File<br>
    <input type="radio" name="choice" value="time"> Display Last Modification Time<br>
    <input type="radio" name="choice" value="size"> Display Size of File<br><br>
    <input type="submit" value="Show">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST['fname'];
    $choice = $_POST['choice'] ?? '';

    if (file_exists($fname)) {
        switch ($choice) {
            case 'type':
                echo "File Type: " . filetype($fname);
                break;
            case 'time':
                echo "Last Modified: " . date("d-m-Y H:i:s", filemtime($fname));
                break;
            case 'size':
                echo "File Size: " . filesize($fname) . " bytes";
                break;
            default:
                echo "Please select an option.";
        }
    } else {
        echo "File not found.";
    }
}
?>

</body>
</html>
