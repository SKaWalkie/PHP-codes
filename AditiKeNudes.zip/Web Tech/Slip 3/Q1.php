<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter a Number: <input type="text" name="num" value="<?php if(isset($_POST['num'])) echo $_POST['num']; ?>">
    <input type="submit" value="Show Series">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $n = $_POST['num'];
    if (is_numeric($n) && $n > 0) {
        $a = 0;
        $b = 1;
        echo "<h3>Fibonacci Series:</h3>";
        echo "$a $b ";
        for ($i = 2; $i < $n; $i++) {
            $c = $a + $b;
            echo "$c ";
            $a = $b;
            $b = $c;
        }
    } else {
        echo "<p>Please enter a valid positive number.</p>";
    }
}
?>

</body>
</html>
