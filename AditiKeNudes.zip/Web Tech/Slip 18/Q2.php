<!DOCTYPE html>
<html>
<body>

<form method="post" enctype="multipart/form-data" action="">
    Select File: <input type="file" name="file"><br><br>
    <input type="submit" value="Upload File">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $name = $_FILES['file']['name'];
        $tmp  = $_FILES['file']['tmp_name'];
        
        // Move uploaded file to "uploads" folder
        if (!is_dir("uploads")) mkdir("uploads");
        move_uploaded_file($tmp, "uploads/" . $name);

        echo "<h3>File Uploaded Successfully!</h3>";
        echo "File Name: $name";
    } else {
        echo "<p>Please select a valid file to upload.</p>";
    }
}
?>

</body>
</html>
