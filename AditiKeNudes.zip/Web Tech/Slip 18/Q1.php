<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter Username: 
    <input type="text" name="uname" value="<?php if(isset($_POST['uname'])) echo $_POST['uname']; ?>">
    <input type="submit" value="Set Cookie">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uname = trim($_POST['uname']);
    if ($uname == "") {
        echo "<p>Please enter a username.</p>";
    } else {
        setcookie("username", $uname, time() + 3600); // Cookie valid for 1 hour
        echo "<p>Cookie 'username' set successfully for 1 hour.</p>";
    }
}

if (isset($_COOKIE['username'])) {
    echo "<h3>Welcome, " . $_COOKIE['username'] . "!</h3>";
}
?>

</body>
</html>
