<!DOCTYPE html>
<html>
<body>

<?php
if(isset($_COOKIE['visits'])) {
    $count = $_COOKIE['visits'] + 1;
    setcookie('visits', $count, time() + 3600);  // valid for 1 hour
    echo "You have visited this page $count times.";
} else {
    setcookie('visits', 1, time() + 3600);
    echo "Welcome, You have visited for first time.";
}
?>
    
</body>
</html>
