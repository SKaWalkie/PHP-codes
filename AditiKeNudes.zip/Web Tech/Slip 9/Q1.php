<!DOCTYPE html>
<html>
<body>

<?php
$conn = pg_connect("host=localhost dbname=yourdbname user=youruser password=yourpassword");

if ($conn) {
    echo "Database connection successful!";
} else {
    echo "Database connection failed.";
}
?>

</body>
</html>
