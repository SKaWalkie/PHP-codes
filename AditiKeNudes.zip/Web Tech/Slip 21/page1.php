<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
  Background Color: <input type="color" name="bg" value="#ffffff">
  Text Color: <input type="color" name="fg" value="#000000">
  <input type="submit" value="Save">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"]=="POST") {
    $bg = $_POST['bg'] ?? '#ffffff';
    $fg = $_POST['fg'] ?? '#000000';
    setcookie("bg", $bg, time()+3600);
    setcookie("fg", $fg, time()+3600);
    echo "Colors saved in cookies. <a href='page2.php'>Go to Page 2</a>";
}
?>

</body>
</html>
