<?php
$bg = $_COOKIE['bg'] ?? '#ffffff';
$fg = $_COOKIE['fg'] ?? '#000000';
?>
<!DOCTYPE html>
<html>
<body style="background: <?= htmlspecialchars($bg) ?>; color: <?= htmlspecialchars($fg) ?>;">

<h3>Colors Applied from Cookies</h3>
<p>This page uses your selected background and text colors.</p>

<a href="page1.php">Change Colors</a> |
<a href="page2.php">View Selected Colors</a>

</body>
</html>
