<!DOCTYPE html>
<html>
<body>

<?php
$bg = $_COOKIE['bg'] ?? '#ffffff';
$fg = $_COOKIE['fg'] ?? '#000000';

echo "<h3>Selected Colors</h3>";
echo "Background: $bg <br>";
echo "Text: $fg <br><br>";
echo "<a href='page3.php'>Go to Page 3 (Apply)</a>";
?>

</body>
</html>
