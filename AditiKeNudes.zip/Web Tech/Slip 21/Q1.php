<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter Filename: <input type="text" name="fname">
    <input type="submit" value="Check File">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = $_POST['fname'];

    if (file_exists($fname)) {
        $size = filesize($fname);
        $mtime = date("d-m-Y H:i:s", filemtime($fname));

        echo "<h3>File Details:</h3>";
        echo "File '$fname' exists.<br>";
        echo "File Size: $size bytes<br>";
        echo "Last Modified: $mtime";
    } else {
        echo "File '$fname' does not exist.";
    }
}
?>

</body>
</html>
