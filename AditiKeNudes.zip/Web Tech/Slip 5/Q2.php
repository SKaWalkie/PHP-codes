<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter First File Name: <input type="text" name="file1"><br><br>
    Enter Second File Name: <input type="text" name="file2"><br><br>
    <input type="submit" value="Append">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $f1 = $_POST['file1'];
    $f2 = $_POST['file2'];

    if (file_exists($f1) && file_exists($f2)) {
        $data = file_get_contents($f1);
        file_put_contents($f2, $data, FILE_APPEND);
        echo "Content of '$f1' appended to '$f2' successfully.";
    } else {
        echo "One or both files do not exist.";
    }
}
?>

</body>
</html>
