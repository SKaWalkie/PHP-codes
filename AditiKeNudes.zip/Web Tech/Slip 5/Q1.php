<!DOCTYPE html>
<html>
<body>

<form method="post" action="">
    Enter Temperature (°C): 
    <input type="text" name="celsius" value="<?php if(isset($_POST['celsius'])) echo $_POST['celsius']; ?>">
    <input type="submit" value="Convert">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $c = trim($_POST['celsius']);
    if ($c == "") {
        echo "<p>Please enter a value.</p>";
    } elseif (!is_numeric($c)) {
        echo "<p>Enter a valid numeric value.</p>";
    } else {
        $f = ($c * 9/5) + 32;
        echo "<h3>$c °C = $f °F</h3>";
    }
}
?>

</body>
</html>
